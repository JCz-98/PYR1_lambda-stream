package P1;



public class Estudiante 
{
	public String codigo;
	public String nombre;
	public String apellido;
	public String f_nac;
	public String[] cursos;
	public int credit;
	
	
	public Estudiante(String cd, String n, String a, String fna, String[] cur, int cred)
	{
		this.codigo = cd;
		this.nombre = n;
		this.apellido = a;
		this.f_nac = fna;
		this.cursos = cur.clone();
		this.credit = cred;
		
		
	}
	
	@Override
    public String toString() 
	{ 
        return String.format
        		(codigo + "\t" + nombre + "\t" + apellido + "\t"+ f_nac + "\t"+ cursos.length + "\t" + credit); 
    } 
	
	
	
	
	

}
