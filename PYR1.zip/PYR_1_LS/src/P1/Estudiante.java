package P1;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Estudiante 
{
	private String codigo;
	private String nombre;
	private String apellido;
	private String f_nac;
	private String[] cursos;
	private int credit;
	
	
	public Estudiante(String cd, String n, String a, String fna, String[] cur, int cred)
	{
		this.codigo = cd;
		this.nombre = n;
		this.apellido = a;
		this.f_nac = fna;
		this.cursos = cur.clone();
		this.credit = cred;
	}
	
	@Override
    public String toString() 
	{ 
        return String.format
        		(codigo + "\t" + nombre + "\t" + apellido + "\t"+ f_nac + "\t"+ Arrays.toString(cursos) + "\t" + credit); 
    }
	
	public void crs_reverse() //metodo especial para orden_2 que ordena cursos al reverso
	{
		List<String> c_order = Arrays.stream(cursos).sorted().collect(Collectors.toList());
		Collections.reverse(c_order);
		
        System.out.println(codigo + "\t" + nombre + "\t" + apellido + "\t"+ f_nac + "\t"+ c_order.toString() + "\t" + credit);
        
		
	}


	public String getCodigo() {
		return codigo;
	}


	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellido() {
		return apellido;
	}


	public void setApellido(String apellido) {
		this.apellido = apellido;
	}


	public String getF_nac() {
		return f_nac;
	}


	public void setF_nac(String f_nac) {
		this.f_nac = f_nac;
	}


	public String[] getCursos() {
		return cursos;
	}


	public void setCursos(String[] cursos) {
		this.cursos = cursos;
	}


	public int getCredit() {
		return credit;
	}


	public void setCredit(int credit) {
		this.credit = credit;
	} 
	
	
	
	
	
	
	

}
