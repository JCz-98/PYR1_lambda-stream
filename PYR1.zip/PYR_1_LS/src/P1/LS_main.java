
package P1;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;



public class LS_main 
{
	public static void main(String [ ] args) throws Exception
	{	
	
		List<Estudiante> mainIndex = Stud_parse.createList();
		
		System.out.printf("%nLista de estudiantes tras lectura: %n");
		for(Estudiante stud : mainIndex)
		{
			System.out.println(stud.toString());
		}
		
		GOstreams.goStreams(mainIndex);

	}
	
}
	
