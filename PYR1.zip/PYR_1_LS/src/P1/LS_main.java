
package P1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;



public class LS_main 
{
	public static void main(String [ ] args) throws Exception
	{	
	
		List<Estudiante> mainIndex = Stud_parse.createList();
		
		for(Estudiante stud : mainIndex)
		{
			System.out.println(stud.toString());
		}

	}
	
}
	
