package P1;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

public class GOstreams 
{
	
	public static void goStreams(List<Estudiante> ST)
	{
		order_1(ST);
		
	}
	
	public static void order_1(List<Estudiante> studs)
	{
		Function<Estudiante, String> byCode = Estudiante::getCodigo;
		
		System.out.printf("%nORDEN 1 (Codigo)%n");
		studs.stream().sorted(Comparator.comparing(byCode)).forEach(System.out::println);
	}

}
