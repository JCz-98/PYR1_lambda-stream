package P1;

public class GOstreams 
{
	

}
