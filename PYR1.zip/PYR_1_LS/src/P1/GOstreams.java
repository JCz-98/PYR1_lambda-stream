package P1;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class GOstreams 
{
	
	public static void goStreams(List<Estudiante> ST)
	{
		order_1(ST);
		order_2(ST);
		
	}
	
	public static void order_1(List<Estudiante> studs)
	{
		//ordenado por codigo
		Function<Estudiante, String> byCode = Estudiante::getCodigo;
		
		System.out.printf("%nORDEN 1 (Codigo)%n");
		studs.stream().sorted(Comparator.comparing(byCode)).forEach(System.out::println);
	}
	
	public static void order_2(List<Estudiante> studs)
	{
		//ordenado por apellido
		Function<Estudiante, String> byLN = Estudiante::getApellido;
		
		System.out.printf("%nORDEN 2 (Apellido)%n");
		studs.stream().sorted(Comparator.comparing(byLN)).forEach(estud -> estud.crs_reverse());
	}
	
	public static void order_3(List<Estudiante> studs)
	{
		//agrupamiento por numero de creditos
		System.out.printf("%nORDEN 3 (Creditos)%n");
		Map<Integer, List<Estudiante>> porCred =
				studs.stream()
				.collect(Collectors.groupingBy(Estudiante::getCredit));
		
		porCred.forEach
		(
				(creditos, stud_per_cred) ->
				{
					System.out.println("Creditos: " + creditos);
					stud_per_cred.forEach(stud -> System.out.printf(" %s%n", stud));
				}
		); //referencia Java How to program pg.756
		
	}
	

}
